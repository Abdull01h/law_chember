# Royal Law Chamber - Website (Bilingual Bangla + English)

This is a simple GitHub Pages-ready website for *Royal Law Chamber*.
Theme: Royal deep-blue + gold with paper-style background and justice scale icon.

## Included
- `index.html` — bilingual (Bangla + English) homepage with Home, Practice Areas, Contact
- `assets/style.css` — styles (royal theme)
- `assets/script.js` — language toggle
- `assets/scale-icon.svg` — scale icon
- `assets/paper-texture.png` — placeholder paper texture

## Contact (embedded on page)
- Phone: +8801337411771
- WhatsApp: +8801787716917
- Email: mdabdull01h@gmail.com

## How to use
1. Replace `assets/paper-texture.png` with a good paper texture image for best visuals.
2. Push this folder to your GitHub repo (e.g., `law_chember`) and enable GitHub Pages from `main` branch root.
3. Your site will be available at: `https://<your-username>.github.io/<repo>/`

## Notes
- The site is static and suitable for GitHub Pages.
- If you want the contact links to submit forms or integrate with back-end, ask and I'll add a contact form (server-side).
