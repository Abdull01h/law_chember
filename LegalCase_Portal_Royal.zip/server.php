<?php
// server.php - receives form, stores in SQLite, creates preliminary PDF (requires fpdf.php)
session_start();
$dbfile = __DIR__ . '/legalcase.sqlite';
$casesDir = __DIR__ . '/cases';
$approvedDir = __DIR__ . '/cases/approved';
@mkdir($casesDir,0755,true); @mkdir($approvedDir,0755,true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.html'); exit; }

$name = trim($_POST['user_name'] ?? '');
$phone = trim($_POST['user_phone'] ?? '');
$title = trim($_POST['case_title'] ?? '');
$desc = trim($_POST['description'] ?? '');

if (!$name || !$title || !$desc) {
    $_SESSION['flash'] = 'সবগুলো আবশ্যক ক্ষেত্র পূরণ করুন / Please fill required fields';
    header('Location: index.html'); exit;
}

// init db if needed
if (!file_exists($dbfile)) {
    $db = new SQLite3($dbfile);
    $db->exec("CREATE TABLE cases (id INTEGER PRIMARY KEY, user_name TEXT, user_phone TEXT, case_title TEXT, description TEXT, status TEXT, serial_no TEXT, pdf_path TEXT, created_at TEXT);");
} else {
    $db = new SQLite3($dbfile);
}

$stmt = $db->prepare('INSERT INTO cases (user_name,user_phone,case_title,description,status,created_at) VALUES (:u,:p,:t,:d,"Pending",:c)');
$stmt->bindValue(':u',$name,SQLITE3_TEXT);
$stmt->bindValue(':p',$phone,SQLITE3_TEXT);
$stmt->bindValue(':t',$title,SQLITE3_TEXT);
$stmt->bindValue(':d',$desc,SQLITE3_TEXT);
$stmt->bindValue(':c',date('c'),SQLITE3_TEXT);
$res = $stmt->execute();
$case_id = $db->lastInsertRowID();
$case = $db->querySingle("SELECT * FROM cases WHERE id = $case_id", true);

// try generate pdf if fpdf.php exists
$pdfname = 'case_' . $case_id . '_' . preg_replace('/[^0-9A-Za-z_\-]/','_',substr($title,0,20)) . '.pdf';
$pdfpath = $casesDir . '/' . $pdfname;
if (file_exists(__DIR__ . '/fpdf.php')) {
    require_once __DIR__ . '/fpdf.php';
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10,'LegalCase Portal',0,1,'C');
    $pdf->Ln(5);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(40,8,'Applicant:',0,0); $pdf->Cell(0,8,$name,0,1);
    $pdf->Cell(40,8,'Title:',0,0); $pdf->Cell(0,8,$title,0,1);
    $pdf->Ln(4);
    $pdf->MultiCell(0,6,"Description:\n" . $desc);
    $pdf->Output('F', $pdfpath);
    $db->exec("UPDATE cases SET pdf_path='" . SQLite3::escapeString(basename($pdfpath)) . "' WHERE id=$case_id");
} else {
    $db->exec("UPDATE cases SET pdf_path='' WHERE id=$case_id");
}

$db->close();
$_SESSION['flash'] = 'সাবমিট সফল / Submitted successfully. Case ID: ' . $case_id;
header('Location: index.html'); exit;
?>