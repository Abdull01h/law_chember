<?php
// Placeholder fpdf.php - replace with official FPDF for real PDF generation.
class FPDF {
    function AddPage(){}
    function SetFont($a,$b,$c){}
    function Cell($w,$h,$txt,$border=0,$ln=0,$align=''){}
    function Ln($h=0){}
    function MultiCell($w,$h,$txt){}
    function Output($dest='',$name='') {
        // placeholder
    }
}
?>