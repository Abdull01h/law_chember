// assets/script.js
document.addEventListener('DOMContentLoaded', function(){
  const bnBtn = document.getElementById('bn-btn');
  const enBtn = document.getElementById('en-btn');

  function setLang(lang){
    document.querySelectorAll('.bn').forEach(el=>el.style.display = (lang==='bn'?'inline':'none'));
    document.querySelectorAll('.en').forEach(el=>el.style.display = (lang==='en'?'inline':'none'));
    if(lang==='bn'){ bnBtn.classList.add('active'); enBtn.classList.remove('active'); }
    else { enBtn.classList.add('active'); bnBtn.classList.remove('active'); }
  }
  bnBtn.addEventListener('click', ()=> setLang('bn'));
  enBtn.addEventListener('click', ()=> setLang('en'));
  // default bangla
  setLang('bn');
});
