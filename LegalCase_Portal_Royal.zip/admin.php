<?php
// admin.php - simple admin panel with login (demo). Default admin: admin/admin123
session_start();
$dbfile = __DIR__ . '/legalcase.sqlite';
$casesDir = __DIR__ . '/cases';
$approvedDir = __DIR__ . '/cases/approved';
@mkdir($casesDir,0755,true); @mkdir($approvedDir,0755,true);

// init admin table on first run
if (!file_exists($dbfile)) {
    $db = new SQLite3($dbfile);
    $db->exec("CREATE TABLE cases (id INTEGER PRIMARY KEY, user_name TEXT, user_phone TEXT, case_title TEXT, description TEXT, status TEXT, serial_no TEXT, pdf_path TEXT, created_at TEXT);");
    $db->exec("CREATE TABLE admins (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, signature_path TEXT, created_at TEXT);");
    $db->exec("INSERT INTO admins (username,password,created_at) VALUES ('admin','" . password_hash('admin123', PASSWORD_DEFAULT) . "',datetime('now'));");
    $db->close();
}

$action = $_REQUEST['action'] ?? 'login';
if ($action == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $u = $_POST['username'] ?? ''; $p = $_POST['password'] ?? '';
    $db = new SQLite3($dbfile);
    $row = $db->querySingle("SELECT * FROM admins WHERE username='" . SQLite3::escapeString($u) . "'", true);
    if ($row && password_verify($p, $row['password'])) {
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_user'] = $row['username'];
        header('Location: admin.php?action=dashboard'); exit;
    } else {
        $err = 'Login failed';
    }
    $db->close();
}

if ($action == 'logout') { session_destroy(); header('Location: admin.php'); exit; }

// Approve case
if ($action == 'approve' && $_SERVER['REQUEST_METHOD']=='POST') {
    if (empty($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }
    $case_id = intval($_POST['case_id'] ?? 0);
    $db = new SQLite3($dbfile);
    $case = $db->querySingle("SELECT * FROM cases WHERE id=$case_id", true);
    if ($case) {
        // generate serial
        $serial = sprintf('LC-%s-%04d', date('Y'), $case_id);
        // mark Investigating
        $pdfname = 'case_' . $case_id . '_' . preg_replace('/[^0-9A-Za-z_\-]/','_',substr($case['case_title'],0,20)) . '.pdf';
        $pdfpath = $approvedDir . '/' . $pdfname;
        if (file_exists(__DIR__ . '/fpdf.php')) {
            require_once __DIR__ . '/fpdf.php';
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial','B',16);
            $pdf->Cell(0,10,'LegalCase Portal - Approved',0,1,'C');
            $pdf->Ln(5);
            $pdf->SetFont('Arial','',12);
            $pdf->Cell(40,8,'Serial:',0,0); $pdf->Cell(0,8,$serial,0,1);
            $pdf->Cell(40,8,'Applicant:',0,0); $pdf->Cell(0,8,$case['user_name'],0,1);
            $pdf->Ln(4);
            $pdf->MultiCell(0,6,"Description:\n" . $case['description']);
            $pdf->Output('F', $pdfpath);
        }
        $db->exec("UPDATE cases SET status='Investigating', serial_no='" . SQLite3::escapeString($serial) . "', pdf_path='" . SQLite3::escapeString(basename($pdfpath)) . "' WHERE id=$case_id");
    }
    $db->close();
    header('Location: admin.php?action=dashboard'); exit;
}

// Dashboard view
if ($action == 'dashboard') {
    if (empty($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }
    $db = new SQLite3($dbfile);
    $pending = $db->query("SELECT * FROM cases WHERE status='Pending' ORDER BY id DESC");
    $all = $db->query("SELECT * FROM cases ORDER BY id DESC");
    $db->close();
    ?>
    <!doctype html><html><head><meta charset="utf-8"><title>Admin - LegalCase</title></head><body>
    <h2>Admin Dashboard</h2>
    <p>Logged in as <?php echo htmlspecialchars($_SESSION['admin_user']); ?> | <a href="admin.php?action=logout">Logout</a></p>
    <h3>Pending Cases</h3>
    <table border="1" cellpadding="6"><tr><th>ID</th><th>Applicant</th><th>Title</th><th>Action</th></tr>
    <?php while($r = $pending->fetchArray(SQLITE3_ASSOC)): ?>
      <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo htmlspecialchars($r['user_name']); ?></td>
        <td><?php echo htmlspecialchars($r['case_title']); ?></td>
        <td>
          <form method="post" action="admin.php?action=approve" style="display:inline">
            <input type="hidden" name="case_id" value="<?php echo $r['id']; ?>">
            <button type="submit">Approve</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
    </table>
    <h3>All Cases</h3>
    <table border="1" cellpadding="6"><tr><th>ID</th><th>Applicant</th><th>Title</th><th>Status</th><th>PDF</th></tr>
    <?php foreach($all as $row): ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo htmlspecialchars($row['user_name']); ?></td>
        <td><?php echo htmlspecialchars($row['case_title']); ?></td>
        <td><?php echo htmlspecialchars($row['status']); ?></td>
        <td><?php if(!empty($row['pdf_path'])) echo '<a href="cases/approved/' . rawurlencode($row['pdf_path']) . '" target="_blank">Download</a>'; else echo 'N/A'; ?></td>
      </tr>
    <?php endforeach; ?>
    </table>
    </body></html>
    <?php
    exit;
}

// login form
?>
<!doctype html><html><head><meta charset="utf-8"><title>Admin Login</title></head><body>
<h2>Admin Login</h2>
<?php if(!empty($err)) echo '<p style="color:red;">' . htmlspecialchars($err) . '</p>'; ?>
<form method="post" action="admin.php?action=login">
  <label>Username</label><input type="text" name="username" required><br>
  <label>Password</label><input type="password" name="password" required><br>
  <button type="submit">Login</button>
</form>
</body></html>
