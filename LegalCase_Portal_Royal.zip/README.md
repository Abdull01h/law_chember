# LegalCase Portal - Royal Style (Bilingual) GitHub Package

This package uses a royal deep-blue + gold color theme and paper-style background.
Replace the placeholder `assets/paper-texture.png` with a real paper texture image for best result.

## Included files
- index.html
- assets/style.css
- assets/script.js
- assets/scale-icon.svg
- server.php
- admin.php
- fpdf.php (placeholder) — replace with official FPDF for PDF generation
- README.md
- .gitignore

## Setup
1. Place folder in PHP webroot or run `php -S 0.0.0.0:8000`
2. Create writable folders if needed: `cases/`, `cases/approved/`, `uploads/`
3. Add real `fpdf.php` from http://www.fpdf.org/ for PDF support

## Default admin
username: admin
password: admin123

## GitHub
Follow normal git push steps to upload to your repository.

